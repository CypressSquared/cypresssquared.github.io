module com.squarecypress.debuggergame {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires javafx.graphics;

    opens com.squarecypress.debuggergame to javafx.fxml;
    exports com.squarecypress.debuggergame;
}
