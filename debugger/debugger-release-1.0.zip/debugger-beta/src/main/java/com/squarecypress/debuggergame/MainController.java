package com.squarecypress.debuggergame;

import java.sql.*;
import java.util.ArrayList;
import java.util.Optional;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.*;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;

public class MainController {

    // initialization for listing out buttons to display during each level
    ArrayList<Hyperlink> buttonList = new ArrayList<Hyperlink>();

    // initialization for storing all of the codeblock levels once they've been imported in via sqlite
    ArrayList<CodeBlocks> codeBlockList = new ArrayList<CodeBlocks>();

    // player stats
    int breachProgress = 0;
    int countermeasureProgress = 0;
    int currentBlockIndex = 0;
    int attackingCurrentIndex = 0;
    CodeBlocks currentBlock;

    @FXML
    private Label breachProgressLabel, countermeasureProgressLabel, codeblockDescription, phaseindicator;
    @FXML
    private StackPane startpage;
    @FXML
    private HBox gamefieldbuttons, gamefieldcompleted;

    Alert popupSuccess = new Alert(AlertType.INFORMATION, "BLOCK VALIDATED");
    Alert popupFail = new Alert(AlertType.INFORMATION, "BLOCK ERROR");
    Alert popupWin = new Alert(AlertType.INFORMATION,
            "YOU SUCCESSFULLY REPELLED THE HACKERS\nYOU WIN\nConfirm to exit.");
    Alert popupLose = new Alert(AlertType.INFORMATION, "SYSTEM BREACH ERROR\nGAME OVER\nConfirm to exit.");
    Alert popupTutorial = new Alert(AlertType.INFORMATION,
            "YOUR SYSTEM HAS DETECTED A BREACH. FOLLOW THE INSTRUCTIONS ON THE SCREEN, READ THEM CAREFULLY.\nYOU HAVE TWO DIRECTIVES.\n\n1. SOLVE THE ORDERING PUZZLES TO BUILD UP YOUR COUNTERMEASURES. THE HACKERS WILL BE REPELLED ONCE YOUR COUNTERMEASURES ARE AT 100%.\n2. SOLVE THE SYNTAX PUZZLES TO PREVENT BREACH PROGRESS. THE HACKERS WILL SUCCEED IF YOUR BREACH PROGRESS REACHES 100%.");

    public void initialization() {

        // sqlite database connection. extract the data inside the database provided, using them to initialize each codeblock level.
        try (
                Connection connection = DriverManager.getConnection("jdbc:sqlite::resource:blockdata.db", null, null);
                Statement statement = connection.createStatement();) {

            ResultSet resultSet = statement
                    .executeQuery("SELECT blockid, blockDescription, trueCodeBlocks, wrongBlocks FROM blockdata");

            while (resultSet.next()) {

                System.out.println("Assembling block ID: " + resultSet.getInt("blockid"));

                // hard to store lists of strings inside one entry, so using regex to split up one long string
                String[] codeBlock = resultSet.getString("trueCodeBlocks").split("~");
                String[] wrongBlocks = resultSet.getString("wrongBlocks").split("~");

                codeBlockList.add(new CodeBlocks(resultSet.getInt("blockid"), resultSet.getString("blockDescription"), codeBlock, wrongBlocks));
            }

        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        generateProgressBars();
        startpage.getChildren().clear();

        generatePhase(true);

        // alert box styling
        initializeAlertBox(popupSuccess, true);
        initializeAlertBox(popupFail, false);
        initializeAlertBox(popupLose, false);
        initializeAlertBox(popupWin, true);
        initializeAlertBox(popupTutorial, true);

        Optional<ButtonType> confirmed = popupTutorial.showAndWait();
        if (confirmed.isPresent() && confirmed.get() == ButtonType.OK) {
            return;
        }

    }


    // set up the alert boxes to css, have to do this manually for each alert box, so a method was made
    void initializeAlertBox(Alert alert, boolean defaultColor) {
        alert.getDialogPane().getStylesheets().add(getClass().getResource("stylesheet.css").toExternalForm());
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setGraphic(null);

        if (!defaultColor) {
            alert.getDialogPane().lookup(".content").setStyle("-fx-text-fill: #e60000;");
        }
    }


    // to generate the ui for progress bars. uses helper method right below it to avoid long repetition and huge if/else chains
    public void generateProgressBars() {
        breachProgressLabel.setText(generateProgressBarText("SYSTEM BREACH DETECTED", breachProgress));
        countermeasureProgressLabel.setText(generateProgressBarText("PREPARING COUNTERMEASURES", countermeasureProgress));
    }


    // logic for calculating the string meant to display the bar
    private String generateProgressBarText(String label, int progress) {
        int asterisks = progress / 5;
        String stars = "*".repeat(asterisks);
        String dashes = "-".repeat(20 - asterisks);
        return String.format("%s\t%d%%\t|%s%s|", label, progress, stars, dashes);
    }


    // logic for generating each level, making sure they alternate
    public void generatePhase(boolean phaseState) {

        if (countermeasureProgress >= 100) {

            Optional<ButtonType> confirmed = popupWin.showAndWait();
            if (confirmed.isPresent() && confirmed.get() == ButtonType.OK) {
                Platform.exit();
            }

        } else if (breachProgress >= 100) {

            Optional<ButtonType> confirmed = popupLose.showAndWait();
            if (confirmed.isPresent() && confirmed.get() == ButtonType.OK) {
                Platform.exit();
            }

        }

        generateProgressBars();

        gamefieldbuttons.getChildren().clear();
        gamefieldcompleted.getChildren().clear();

        currentBlockIndex = (int) (Math.random() * codeBlockList.size());
        currentBlock = codeBlockList.get(currentBlockIndex);
        currentBlock.scrambleCodeBlock();
        currentBlock.assembleWrongCodeBlock();
        if (phaseState) {
            phaseindicator.setText("Assemble the code in the correct order by clicking on each piece of code.");
            generateButtonsAttack(currentBlock);
        } else {
            phaseindicator
                    .setText("Click on the wrong parts of the code to correct it, until the block of code is correct.");
            generateButtonsDefense(currentBlock);
        }
    }


    // logic for generating the required buttons for the assembling level and also for the level itself
    public void generateButtonsAttack(CodeBlocks codeblock) {

        System.out.println("Attacking phase");

        buttonList.clear();
        attackingCurrentIndex = 0;

        codeblockDescription.setText(codeblock.blockDescription);

        int buttonGeneratorCounter = 0;
        for (String block : codeblock.scrambledCodeBlock) {

            buttonList.add(new Hyperlink(block));

            buttonList.get(buttonGeneratorCounter).setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {

                    System.out.println("Buttonpress '" + block + "' checking against '"
                            + currentBlock.codeBlock.get(attackingCurrentIndex) + "'.");
                    if (block.equals(currentBlock.codeBlock.get(attackingCurrentIndex))) {
                        for (Hyperlink hyperlink : buttonList) {
                            if (hyperlink.getText().equals(block)) {
                                gamefieldbuttons.getChildren().remove(hyperlink);
                            }
                        }
                        System.out.println("Button should be deleted.");
                        attackingCurrentIndex++;

                        gamefieldcompleted.getChildren().add(new Label(block));

                        if (attackingCurrentIndex >= currentBlock.codeBlock.size()) {
                            Optional<ButtonType> confirmed = popupSuccess.showAndWait();
                            if (confirmed.isPresent() && confirmed.get() == ButtonType.OK) {
                                countermeasureProgress = countermeasureProgress + (int) ((Math.random() * 20) + 5);
                                if (countermeasureProgress > 100) {
                                    countermeasureProgress = 100;
                                }
                                gamefieldcompleted.getChildren().clear();
                                generatePhase(false);
                            }
                        }
                    } else {
                        System.out.println("Phase failed.");

                        gamefieldbuttons.getChildren().clear();
                        gamefieldcompleted.getChildren().clear();

                        for (String block : currentBlock.codeBlock) {
                            gamefieldcompleted.getChildren().add(new Label(block));
                        }

                        Optional<ButtonType> confirmed = popupFail.showAndWait();
                        if (confirmed.isPresent() && confirmed.get() == ButtonType.OK) {
                            gamefieldcompleted.getChildren().clear();
                            generatePhase(false);
                        }
                    }
                };
            });

            buttonGeneratorCounter++;
        }
        gamefieldbuttons.getChildren().clear();
        gamefieldbuttons.getChildren().addAll(buttonList);
    }

        // logic for generating the required buttons for the debugging level and also for the level itself
    public void generateButtonsDefense(CodeBlocks codeblock) {

        System.out.println("Defending phase");

        buttonList.clear();

        int defendingIndex = 0;

        codeblockDescription.setText(codeblock.blockDescription);

        int buttonGeneratorCounter = 0;
        for (String block : codeblock.wrongCodeBlock) {

            int localDefendingIndex = defendingIndex;

            buttonList.add(new Hyperlink(block));

            buttonList.get(buttonGeneratorCounter).setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {

                    System.out.println("Checking index: " + localDefendingIndex + " content: " + block + ", against "
                            + currentBlock.codeBlock.get(localDefendingIndex));

                    if (block.equals(currentBlock.codeBlock.get(localDefendingIndex))) {

                        System.out.println("Phase failed.");

                        gamefieldbuttons.getChildren().clear();
                        for (String block : currentBlock.codeBlock) {
                            gamefieldcompleted.getChildren().add(new Label(block));
                        }

                        Optional<ButtonType> confirmed = popupFail.showAndWait();
                        if (confirmed.isPresent() && confirmed.get() == ButtonType.OK) {
                            breachProgress = breachProgress + (int) ((Math.random() * 20) + 5);
                            if (breachProgress > 100) {
                                breachProgress = 100;
                            }
                            generatePhase(true);
                        }

                    } else {
                        currentBlock.wrongCodeBlock.set(localDefendingIndex,
                                currentBlock.codeBlock.get(localDefendingIndex));
                        buttonList.get(localDefendingIndex).setText(currentBlock.codeBlock.get(localDefendingIndex));
                    }

                    if (currentBlock.wrongCodeBlock.equals(currentBlock.codeBlock)) {
                        gamefieldbuttons.getChildren().clear();
                        for (String block : currentBlock.codeBlock) {
                            gamefieldcompleted.getChildren().add(new Label(block));
                        }

                        Optional<ButtonType> confirmed = popupSuccess.showAndWait();
                        if (confirmed.isPresent() && confirmed.get() == ButtonType.OK) {
                            System.out.println("Phase successful");
                            generatePhase(true);
                        }
                    }
                };
            });

            buttonGeneratorCounter++;
            defendingIndex++;
        }

        gamefieldbuttons.getChildren().clear();
        gamefieldbuttons.getChildren().addAll(buttonList);

    }

}
