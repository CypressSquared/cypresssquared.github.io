package com.squarecypress.debuggergame;

import javafx.application.*;
import javafx.fxml.*;
import javafx.stage.*;
import javafx.scene.*;

public class App extends Application {

    @Override
    public void start(@SuppressWarnings("exports") Stage stage) throws Exception {

        //  Linking the app to the fxml file
        Parent root = FXMLLoader.load(getClass().getResource("app.fxml"));
        
        //  Setting up the scene
        Scene scene = new Scene(root, 600, 400);
        scene.getStylesheets().add(getClass().getResource("stylesheet.css").toExternalForm());
        
        stage.setTitle("Debugger.jar");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
        
    }


    public static void main(String[] args) {
        launch(args);
    }


}