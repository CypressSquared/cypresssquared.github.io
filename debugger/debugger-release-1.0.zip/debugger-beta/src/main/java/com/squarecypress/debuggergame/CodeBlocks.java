package com.squarecypress.debuggergame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class CodeBlocks {

    // variables to store the data from the database
    ArrayList<String> codeBlock = new ArrayList<String>();
    ArrayList<String> scrambledCodeBlock = new ArrayList<String>();
    ArrayList<String> tempCodeBlock = new ArrayList<String>();
    ArrayList<String> wrongBlocks = new ArrayList<String>();
    ArrayList<String> wrongCodeBlock = new ArrayList<String>();
    int blockid;
    String blockDescription;

    static Random random = new Random();


    // constructor for initializing the data into the variables
    CodeBlocks(int setid, String setDesc, String[] blocksSetter, String[] wrongBlocksSetter) {
        blockid = setid;

        blockDescription = setDesc;

        for (String i : blocksSetter) {
            codeBlock.add(i);
            scrambledCodeBlock.add(i);
        }   

        for (String i : wrongBlocksSetter) {
            wrongBlocks.add(i);
        }

        scrambleCodeBlock();

        assembleWrongCodeBlock();
    }

    // shuffles elements in the array
    void scrambleCodeBlock() {
        Collections.shuffle(scrambledCodeBlock);
    }

    // logic for creating data for the debugging levels. it generates a random number up to 50% of the total number of elements in the provided array, then swaps out random elements in the 'correct' array with elements in the corresponding 'wrong' array
    void assembleWrongCodeBlock() {

        int blockChanges = (int)(random.nextInt(codeBlock.size()) * 0.50);

        if (blockChanges == 0) {
            blockChanges++;
        }

        System.out.println("Assembling wrong block.");
        System.out.println("Number of blocks changed: " + blockChanges);

        wrongCodeBlock.clear();

        for (String i : codeBlock) {
            wrongCodeBlock.add(i);
        }
        

        for (int i = 0; i < blockChanges; i++) {
            
            int randomIndex = random.nextInt(codeBlock.size());

            wrongCodeBlock.set(randomIndex, wrongBlocks.get(randomIndex)); 

            System.out.println("Index changed: " + randomIndex + ". Changed to: " + wrongCodeBlock.get(randomIndex));

        }

        System.out.println("Wrong block successfully assembled.");

    }
}
